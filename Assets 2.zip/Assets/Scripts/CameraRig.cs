using UnityEngine;

public class CameraRig : MonoBehaviour
{
    public GameObject targetObject;
    public Vector3 camOffset;
    private Vector3 targetPos;
    public float interpolationRatio = 0.75f;

    private void Start()
    {
        targetObject = GameObject.FindGameObjectWithTag("Base");
        ChangeTarget();

    }
    
    private void Update()
    {/*
        // Vérifier si l'utilisateur clique sur un autre objet
        if (Input.GetMouseButtonUp(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit) && hit.collider.gameObject.GetComponent<Clickable>() != null)
            {

                    targetObject = hit.collider.gameObject;

                    // Positionner la caméra au-dessus de l'objet cliqué
                    transform.position = new Vector3(targetObject.transform.position.x, transform.position.y, targetObject.transform.position.z);
            }
        }*/

        transform.position = Vector3.Lerp(transform.position, targetPos,interpolationRatio);
    }
    
    public void ChangeTarget()
    {
        if (targetObject != null)
        {
            targetPos = new Vector3(targetObject.transform.position.x, transform.position.y, camOffset.z);
            Debug.Log(targetObject);
        }

    } 
}
