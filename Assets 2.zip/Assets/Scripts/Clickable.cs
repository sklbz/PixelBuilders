using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Clickable : MonoBehaviour
{
    private CameraRig mainCamera;

    void Start()
    {
        mainCamera = FindObjectOfType<CameraRig>();    
    }

    void OnMouseDown()
    {
        Debug.Log("hello");
        mainCamera.targetObject = gameObject;
        mainCamera.ChangeTarget();
    }
}
