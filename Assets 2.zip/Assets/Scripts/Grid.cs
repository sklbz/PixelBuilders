using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grid : MonoBehaviour
{
  /*
    Transform[] allChildren;
    GameManager gm;
    void Start()
    {
        gm = FindObjectOfType<GameManager>();
        allChildren = GetComponentsInChildren<Transform>();
        for(int i = 0; i < allChildren.Length; i++) {
            gm.tiles[i] = (Tile)allChildren[i];
        }
    }
    */
}
